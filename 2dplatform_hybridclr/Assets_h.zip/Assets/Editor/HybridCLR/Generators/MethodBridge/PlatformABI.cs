﻿namespace HybridCLR.Editor.Generators.MethodBridge
{
    public enum PlatformABI
    {
        Universal32,
        Universal64,
        Arm64,
    }
}
