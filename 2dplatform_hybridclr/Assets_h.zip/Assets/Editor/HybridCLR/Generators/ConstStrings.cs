﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HybridCLR.Editor.Generators
{
    internal static class ConstStrings
    {
        public const string typeObjectPtr = "Il2CppObject*";
    }
}
